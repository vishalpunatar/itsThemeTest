<?php
/**
 * Plugin Name: My Custom Plugin
 * Description: Simple custom WordPress plugin starter.
 * Version: 1.0.0
 * Author: Vishal
 */

if (!defined('ABSPATH')) {
    exit;
}

function mcp_hello_shortcode()
{
    return '<h2>Hello From My Custom Plugin</h2>';
}

add_shortcode('mcp_hello', 'mcp_hello_shortcode');
