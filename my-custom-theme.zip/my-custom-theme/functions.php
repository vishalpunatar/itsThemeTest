<?php

if (!defined('ABSPATH')) {
    exit;
}

function mct_enqueue_assets()
{
    wp_enqueue_style('mct-style', get_stylesheet_uri(), [], '1.0');
}

add_action('wp_enqueue_scripts', 'mct_enqueue_assets');
